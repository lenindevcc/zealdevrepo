# -*- coding: utf-8 -*-

import addonvar



current_build = addonvar.setting('buildname')

try:

	current_version = float(addonvar.setting('buildversion')) 

except:

	current_version = 0.0



class startup:

	def save_menu(self):

		save_items = []

		choices = ["Favourites", "Sources", "Debrid - Resolve URL", "Advanced Settings"]

		save_select = addonvar.dialog.multiselect(addonvar.addon_name + " - Select items to keep during a build install.",choices, preselect=[])

		if save_select == None:

			return

		else:

			for index in save_select:

				save_items.append(choices[index])

		if 'Favourites' in save_items:

			addonvar.setting_set('savefavs','true')

		else:

			addonvar.setting_set('savefavs','false')

		if 'Sources' in save_items:

			addonvar.setting_set('savesources', 'true')

		else:

			addonvar.setting_set('savesources', 'false')

		if 'Debrid - Resolve URL' in save_items:

			addonvar.setting_set('savedebrid','true')

		else:

			addonvar.setting_set('savedebrid','false')

		if 'Advanced Settings' in save_items:

			addonvar.setting_set('saveadvanced','true')

		else:

			addonvar.setting_set('saveadvanced','false')

	

		addonvar.setting_set('firstrunSave', 'true')

	

	def check_updates(self):

	   	if current_build == 'No Build Installed':

	   		return

	   	response = self.get_page(addonvar.buildfile)
        response = self.get_page(addonvar.buildfile1)

	   	version = 0.0

	   	try:

	   		import json
	   		builds = json.loads(response)['builds']

	   		for build in builds:

	   				if build.get('name') == current_build:

	   					version = float(build.get('version'))

	   					break

	   	except:
	   		import xml.etree.ElementTree as ET
	   		builds = ET.fromstring(response)

	   		for tag in builds.findall('build'):

	   				if tag.find('name').text == current_build:

	   					version = float(tag.find('version').text)

	   					break

	   	if version > current_version:

	   		addonvar.dialog.ok(addonvar.addon_name, 'A new version of ' + current_build +' is available.' + '\n' + 'Installed Version: ' + str(current_version) + '\n' + 'New Version: ' + str(version) + '\n' + 'You can update from the Build Menu in ' + addonvar.addon_name + '.')

	   	else:

	   		return

	

	def notify_check(self):

		notify_version = self.get_notifyversion()	

		if not addonvar.setting('firstrunNotify')=='true' or notify_version > int(addonvar.setting('notifyversion')):

			self.notification()

	

	def file_check(self, bfile):
		import base64


		if addonvar.isBase64(bfile):

			return base64.b64decode(bfile).decode('utf8')

		else:

			return bfile

			

	def get_page(self, url):

	   	from urllib.request import Request,urlopen

	   	req = Request(self.file_check(url), headers = addonvar.headers)

	   	return urlopen(req).read()

			

	def notification(self):

		from resources.lib.GUIcontrol import notify

		d=notify.notify()

		d.doModal()

		del d

		addonvar.setting_set('firstrunNotify', 'true')

		addonvar.setting_set('notifyversion', str(self.get_notifyversion()))

	

	def get_notifyversion(self):

		response = self.get_page(addonvar.notify_url).decode('utf-8')

		try:

			split_response = response.split('|||')

			return int(split_response[0])	

		except:

			return False	



	def run_startup(self):

		if not addonvar.setting('firstrunSave')=='true':

			self.save_menu()

		self.check_updates()

		self.notify_check()

		if addonvar.setting('firstrun') == 'true':

			from resources.lib.modules import addonsEnable

			addonsEnable.enable_addons()
			import xbmc
			xbmc.executebuiltin('UpdateLocalAddons')

			xbmc.executebuiltin('UpdateAddonRepos')