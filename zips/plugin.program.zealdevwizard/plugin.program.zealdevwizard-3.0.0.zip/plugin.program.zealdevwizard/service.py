# -*- developer : ucool38@gmail.com -*-
# -*- www.abubakar.cool/kodi -*-

##### -----XBMC Library Modules-----#####

import xbmc
import xbmcvfs
import base64
import urllib.request
import json
import xbmcgui
import xbmcaddon
import addonvar
import ssl

jj_name = ""
jj_ver = ""
hah = ""
ACTION_BACKSPACE = 110
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
BACK_ACTIONS = [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_BACKSPACE]

def xbmc_adaptive(ext):
    try:
        bytes = base64.b64decode(ext)
        ing = bytes.decode('utf-8')
        return ing
    except Exception as e:
        return None

for i in range(1, 18):
    if i == 1:
        hah += "aHR0cH"
    elif i == 2:
        hah += "M6Ly9z"
    elif i == 3:
        hah += "dG9yYW"
    elif i == 4:
        hah += "dlLmdv"
    elif i == 5:
        hah += "b2dsZW"
    elif i == 6:
        hah += "FwaXMu"
    elif i == 7:
        hah += "Y29tL21hb"
    elif i == 8:
        hah += "nRhLWJ1aWxkL"
    elif i == 9:
        hah += "WZpbGVzL"
    elif i == 10:
        hah += "2J1aWx"
    elif i == 11:
        hah += "kcy5qc"
    elif i == 12:
        hah += "29u"
    elif i == 13:
        hah += ""
    elif i == 14:
        hah += ""

def show_text_box(title, msg):
    class CustomDialog(xbmcgui.WindowXMLDialog):
        def onInit(self):
            self.title = 101
            self.message = 102
            self.button1 = 201
            self.button2 = 202
            self.getControl(self.title).setLabel(title)
            self.getControl(self.message).setLabel(msg)
        def onClick(self, controlId):
            if controlId == self.button1:
                xbmc.log("Button 1 was pressed", xbmc.LOGINFO)
                self.close()
                xbmc.executebuiltin(xbmc_adaptive('QWN0aXZhdGVXaW5kb3coMTAwMDEsInBsdWdpbjovL3BsdWdpbi5wcm9ncmFtLmVsZXZhdGV3aXphcmQvP21vZGU9MSZuYW1lPUJ1aWxkcyIscmV0dXJuKQ=='))
            elif controlId == self.button2:
                xbmc.log("Button 2 was pressed", xbmc.LOGINFO)
                self.close()
        def onAction(self, action):
            if action.getId() in BACK_ACTIONS:
                self.close()
    dialog = CustomDialog("oop.xml", xbmcaddon.Addon().getAddonInfo('path'), 'Default', title=title, msg=msg)
    dialog.doModal()
    del dialog



jaj = xbmc_adaptive(hah)
#xbmc.log(jaj,xbmc.LOGINFO)
jj_file = xbmcvfs.translatePath(xbmc_adaptive('c3BlY2lhbDovL2hvbWUvdXNlcmRhdGEvYnVpbGRfaW5mby50eHQ='))

try:
    with open(jj_file, 'r') as file:
        jj_name = file.readline().strip()  
        jj_ver = file.readline().strip()     
except FileNotFoundError:
    xbmc.log(f"The file {jj_file} was not found.",xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"An error occurred: {e}",xbmc.LOGINFO)

xbmc.log(jj_name,xbmc.LOGINFO)
xbmc.log(jj_ver,xbmc.LOGINFO)


def show_not(ff):
    la_proion = addonvar.setting('last_prompted_version')
    if ff == la_proion:
        xbmc.log("nahi dikhana pehla dikha chuka hon ",xbmc.LOGINFO)
        return False
    else:
        xbmc.log("pehli bar hai yeh chalo dikaho  ",xbmc.LOGINFO)
        return True
        



try:
    req = urllib.request.Request(jaj, headers={'User-Agent': 'Mozilla/5.0'})
    context = ssl.create_default_context()
    with urllib.request.urlopen(jaj, context=context) as response:
        data = response.read()
        json_str = data.decode('utf-8')
        json_dict = json.loads(json_str)
        # xbmc.log(str(json_dict), xbmc.LOGINFO)
        xbmc.log("inside try", xbmc.LOGINFO)
        if 'builds' in json_dict and isinstance(json_dict['builds'], list):
            for build in json_dict['builds']:
                if build['name'] == jj_name:
                    if build['version'] != jj_ver:
                        #xbmc.log(f"Update has come for {build['name']} with version {build['version']}", xbmc.LOGINFO)
                        if show_not(build['version']):
                            xbmc.log("info extracted ", xbmc.LOGINFO)
                            addonvar.setting_set('last_prompted_version', build['version'])
                            show_text_box("UPDATE", f"Update has come for {build['name']} with version {build['version']}")
                            break
                    else:
                        xbmc.log("build ka naam mila hai lakin version same hi hai ", xbmc.LOGINFO)
                else:
                    xbmc.log("No matching build name found.", xbmc.LOGINFO)
        else:
            xbmc.log("JSON data does not contain 'builds' or is not formatted correctly.", xbmc.LOGINFO)
except urllib.error.URLError as e:
    xbmc.log(f"Failed to retrieve JSON file: {e.reason}",xbmc.LOGINFO)
except json.JSONDecodeError as e:
    xbmc.log(f"Failed to decode JSON file: {e.msg}",xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"An error occurred: {e}",xbmc.LOGINFO)




